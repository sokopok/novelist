#include "client.h"
#include "response.h"

namespace ai::responses {

Client::Client(QObject *parent)
    : Client{new RequestData, parent}
{}

Client::Client(RequestData *data, QObject *parent)
    : ai::Client{data ? data : new RequestData, parent}
{
    resetApiKey();
    resetApiUrl();
    resetMetadata();
    resetModel();
    resetStreaming();
    resetStreamOptions();
}

bool Client::prepareRequest(Request *request)
{
    if (!ai::Client::prepareRequest(request))
        return false;

    if (!request->isExplicit(Request::BackgroundAttribute)) {
        if (d()->isExplicit(Request::BackgroundAttribute))
            request->setBackground(background());
        else {
            setError(
                {Error::InternalErrorType, Error::InternalError, "prepareRequest", "background"});
            return false;
        }
    }

    if (!request->isExplicit(Request::ConversationAttribute)) {
        if (d()->isExplicit(Request::ConversationAttribute))
            request->setConversation(conversation());
        else {
            setError(
                {Error::InternalErrorType, Error::InternalError, "prepareRequest", "conversation"});
            return false;
        }
    }

    if (!request->isExplicit(Request::IncludeAttribute)) {
        if (d()->isExplicit(Request::IncludeAttribute))
            request->setInclude(include());
    } else if (d()->isExplicit(Request::IncludeAttribute)) {
        auto md = metadata();
        for (auto it = request->metadata().begin(), end = request->metadata().end(); it != end; ++it)
            md[it.key()] = it.value();
        request->setMetadata(md);
    }

    if (!request->isExplicit(Request::InstructionsAttribute)) {
        if (d()->isExplicit(Request::InstructionsAttribute))
            request->setInstructions(instructions());
    } else if (d()->isExplicit(Request::InstructionsAttribute))
        request->setInstructions(instructions() + '\n' + request->instructions());

    if (!request->isExplicit(Request::StoredAttribute)) {
        if (d()->isExplicit(Request::StoredAttribute))
            request->setStored(isStored());
        else {
            setError({Error::InternalErrorType, Error::InternalError, "prepareRequest", "store"});
            return false;
        }
    }

    if (!request->isExplicit(Request::TemperatureAttribute)) {
        if (d()->isExplicit(Request::TemperatureAttribute))
            request->setTemperature(temperature());
        else {
            setError(
                {Error::InternalErrorType, Error::InternalError, "prepareRequest", "temperature"});
            return false;
        }
    }

    return true;
}

Response *Client::post(const Request &request, QIODevice *device)
{
    auto *network = networkAccessManager();
    if (!network) {
        setError({Error::InternalErrorType, Error::InternalError, "No networkAccessManager"});
        return nullptr;
    }

    Request r = request;

    if (!prepareRequest(&r)) {
        setError({Error::InternalErrorType, Error::InternalError, "Couldn't prepare request"});
        return nullptr;
    }

    if (!validateRequest(r)) {
        setError({Error::InternalErrorType, Error::InternalError, "Couldn't validate request"});
        return nullptr;
    }

    const auto data = QJsonDocument{r.toJson()}.toJson();

    qDebug().noquote().nospace() << toJson(true);
    qDebug().noquote().nospace() << r.url().toString() << '\n' << data;

    return new Response{r, network->post(r, data), this};
}

bool Client::validateRequest(const Request &request) const
{
    if (!ai::Client::validateRequest(request))
        return false;

    if (!request.conversation().isValid()) {
        return false;
    }

    if (!request.input().isValid()) {
        return false;
    }

    return true;
}

void Client::setPopulateRequestBehaviour(const PopulateRequestBehaviour &populateRequestBehaviour)
{
    if (mPopulateRequestBehaviour == populateRequestBehaviour)
        return;
    mPopulateRequestBehaviour = populateRequestBehaviour;
    emit populateRequestBehaviourChanged();
}

bool Client::background() const
{
    return d()->background();
}

Client &Client::setBackground(bool background)
{
    d()->setBackground(background);
    return *this;
}

Client &Client::resetBackground()
{
    d()->resetBackground();
    return *this;
}

Conversation Client::conversation() const
{
    return d()->conversation();
}

Client &Client::setConversation(const Conversation &conversation)
{
    d()->setConversation(conversation);
    return *this;
}

Client &Client::resetConversation()
{
    d()->resetConversation();
    return *this;
}

IncludeList Client::include() const
{
    return d()->include();
}

Client &Client::setInclude(const IncludeList &include)
{
    d()->setInclude(include);
    return *this;
}

Client &Client::resetInclude()
{
    d()->resetInclude();
    return *this;
}

Input Client::input() const
{
    return d()->input();
}

Client &Client::setInput(const Input &input)
{
    d()->setInput(input);
    return *this;
}

Client &Client::resetInput()
{
    d()->resetInput();
    return *this;
}

QString Client::instructions() const
{
    return d()->instructions();
}

Client &Client::setInstructions(const QString &instructions)
{
    d()->setInstructions(instructions);
    return *this;
}

Client &Client::resetInstructions()
{
    d()->resetInstructions();
    return *this;
}

Client &Client::resetMaxOutputTokens()
{
    d()->resetMaxOutputTokens();
    return *this;
}

Client &Client::resetMaxToolCalls()
{
    d()->resetMaxToolCalls();
    return *this;
}

QString Client::previousResponseId() const
{
    return d()->previousResponseId();
}

Client &Client::setPreviousResponseId(const QString &previousResponseId)
{
    d()->setPreviousResponseId(previousResponseId);
    return *this;
}

Client &Client::resetPreviousResponseId()
{
    d()->resetPreviousResponseId();
    return *this;
}

Client &Client::resetPromptCacheKey()
{
    d()->resetPromptCacheKey();
    return *this;
}

Reasoning Client::reasoning() const
{
    return d()->reasoning();
}

Client &Client::setReasoning(const Reasoning &reasoning)
{
    d()->setReasoning(reasoning);
    return *this;
}

Client &Client::resetReasoning()
{
    d()->resetReasoning();
    return *this;
}

Client &Client::resetSafetyIdetifier()
{
    d()->resetSafetyIdetifier();
    return *this;
}

Client &Client::resetServiceTier()
{
    d()->resetServiceTier();
    return *this;
}

bool Client::isStored() const
{
    return d()->isStored();
}

Client &Client::setStored(bool store)
{
    d()->setStored(store);
    return *this;
}

double Client::temperature() const
{
    return d()->temperature();
}

Client &Client::setTemperature(double temperature)
{
    d()->setTemperature(temperature);
    return *this;
}

Client &Client::resetTemperature()
{
    d()->resetTemperature();
    return *this;
}

Client &Client::resetTopLogprobs()
{
    d()->resetTopLogprobs();
    return *this;
}

Client &Client::resetTopP()
{
    d()->resetTopP();
    return *this;
}

Client &Client::resetTruncation()
{
    d()->resetTruncation();
    return *this;
}

} // namespace ai::responses
