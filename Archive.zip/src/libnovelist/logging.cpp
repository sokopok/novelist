#include "logging.h"

Q_LOGGING_CATEGORY(LOGNOVELIST, "novelist")
Q_LOGGING_CATEGORY(LOGNOVELISTAI, "novelist.ai")
