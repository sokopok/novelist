#include "novelist.h"

namespace novelist {

Novelist::Novelist(QObject* parent)
    : QObject{parent}
{}

} // namespace novelist
