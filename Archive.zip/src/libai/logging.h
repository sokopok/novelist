#ifndef AI_LOGGING_H
#define AI_LOGGING_H

#include <QLoggingCategory>

Q_DECLARE_LOGGING_CATEGORY(LOGAI)

#endif // AI_LOGGING_H
