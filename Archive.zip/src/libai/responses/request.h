#ifndef AI_RESPONSES_REQUEST_H
#define AI_RESPONSES_REQUEST_H

#include "../request.h"

namespace ai::responses {

class Client;
class RequestData;

class Request : public ai::Request
{
    Q_GADGET

protected:
    RequestData* d();
    const RequestData* d() const;

public:
    enum Attribute {
        BackgroundAttribute = ai::Request::NumAttributes,
        ConversationAttribute,
        IncludeAttribute,
        InputAttribute,
        InstructionsAttribute,
        MaxOutputTokensAttribute,
        MaxToolCallsAttribute,
        ParallelToolCallsAttribute,
        PreviousResponseIdAttribute,
        PromptAttribute,
        PromptCacheKeyAttribute,
        ReasoningAttribute,
        SafetyIdentifierAttribute,
        ServiceTierAttribute,
        StoredAttribute,
        TemperatureAttribute,
        TextAttribute,
        ToolChoiseAttribute,
        ToolsAttribute,
        TopLogprobsAttribute,
        TopPAttribute,
        TruncationAttribute,
        NumAttributes
    };
    Q_ENUM(Attribute)

    enum Truncation { TruncationAuto, TruncationDisabled };

    Request();

    Request& operator=(const ai::Request& rhs);

    [[nodiscard]] bool background() const;
    Request& setBackground(bool background);
    Request& resetBackground();

    [[nodiscard]] Conversation conversation() const;
    Request& setConversation(const Conversation& conversation);
    Request& resetConversation();

    [[nodiscard]] IncludeList include() const;
    Request& setInclude(const IncludeList& include);
    Request& resetInclude();

    [[nodiscard]] Input input() const;
    Request& setInput(const Input& input);
    Request& resetInput();

    [[nodiscard]] QString instructions() const;
    Request& setInstructions(const QString& instructions);
    Request& resetInstructions();

    [[nodiscard]] int maxOutputTokens() const;
    Request& setMaxOutputTokens(int maxOutputTokens);
    Request& resetMaxOutputTokens();

    [[nodiscard]] int maxToolCalls() const;
    Request& setMaxToolCalls(int maxToolCalls);
    Request& resetMaxToolCalls();

    [[nodiscard]] bool parallelToolCalls() const;
    Request& setParallelToolCalls(bool parallelToolCalls);
    Request& resetParallelToolCalls();

    [[nodiscard]] QString previousResponseId() const;
    Request& setPreviousResponseId(const QString& previousResponseId);
    Request& resetPreviousResponseId();

    // [[nodiscard]] AiPrompt prompt() const;
    // Request& setPrompt(const AiPrompt& prompt);
    // Request& resetPrompt() { return setPrompt({}); }

    [[nodiscard]] QString promptCacheKey() const;
    Request& setPromptCacheKey(const QString& promptCacheKey);
    Request& resetPromptCacheKey();

    [[nodiscard]] Reasoning reasoning() const;
    Request& setReasoning(const Reasoning& reasoning);
    Request& resetReasoning();

    [[nodiscard]] QString safetyIdetifier() const;
    Request& setSafetyIdetifier(const QString& safetyIdetifier);
    Request& resetSafetyIdetifier();

    [[nodiscard]] QString serviceTier() const;
    Request& setServiceTier(const QString& serviceTier);
    Request& resetServiceTier();

    [[nodiscard]] bool isStored() const;
    Request& setStored(bool store);
    Request& resetStored();

    [[nodiscard]] double temperature() const;
    Request& setTemperature(double temperature);
    Request& resetTemperature();

    // [[nodiscard]] AiText text() const;
    // Request& setText(const AiText& text);
    // Request& resetText() {return  setText({}); }

    // [[nodiscard]] AiToolChoice toolChoice() const;
    // Request& setToolChoice(const AiToolChoice& toolChoice);
    // Request& resetToolChoice() {return  setToolChoice({}); }

    // [[nodiscard]] AiTools tools() const;
    // Request& setTools(const AiTools& tools);
    // Request& resetTools() { return setTools({}); }

    [[nodiscard]] int topLogprobs() const;
    Request& setTopLogprobs(int topLogprobs);
    Request& resetTopLogprobs();

    [[nodiscard]] double topP() const;
    Request& setTopP(double topP);
    Request& resetTopP();

    [[nodiscard]] Truncation truncation() const;
    Request& setTruncation(Truncation truncation);
    Request& setTruncation(const QString& truncation);
    Request& resetTruncation();

protected:
    Request(RequestData* data);

    // bool readJson(const QJsonObject& json, QStringList* errors = nullptr) override;
    // bool writeJson(QJsonObject& json, bool full = false) const override;

    friend class Client;
};

class RequestData : public ai::RequestData
{
    bool mBackground = false;
    Conversation mConversation;
    IncludeList mInclude;
    Input mInput;
    QString mInstructions;
    int mMaxOutputTokens = 0;
    int mMaxToolCalls = 0;
    bool mParallelToolCalls = true;
    QString mPreviousResponseId;
    QString mPromptCacheKey;
    Reasoning mReasoning;
    bool mStored = true;
    double mTemperature = 1.0;

public:
    enum Truncation { TruncationAuto, TruncationDisabled };

    [[nodiscard]] bool background() const { return mBackground; }
    bool setBackground(bool background,
                       Request::ExplicitHandling explicitHandling = Request::SetExplicit)
    {
        updateExplicit(Request::BackgroundAttribute, explicitHandling);
        if (mBackground == background)
            return false;
        mBackground = background;
        return true;
    }
    void resetBackground(Request::ExplicitHandling explicitHandling = Request::ClearExplicit)
    {
        setBackground(false, explicitHandling);
    }

    [[nodiscard]] Conversation conversation() const { return mConversation; }
    bool setConversation(const Conversation& conversation,
                         Request::ExplicitHandling explicitHandling = Request::SetExplicit)
    {
        updateExplicit(Request::ConversationAttribute, explicitHandling);
        if (mConversation == conversation)
            return false;
        mConversation.setId(conversation.id());
        return true;
    }
    void resetConversation(Request::ExplicitHandling explicitHandling = Request::ClearExplicit)
    {
        setConversation({}, explicitHandling);
    }

    [[nodiscard]] IncludeList include() const { return mInclude; }
    bool setInclude(const IncludeList& include,
                    Request::ExplicitHandling explicitHandling = Request::SetExplicit)
    {
        updateExplicit(Request::ConversationAttribute, explicitHandling);
        if (mInclude == include)
            return false;
        mInclude = include;
        return true;
    }
    void resetInclude(Request::ExplicitHandling explicitHandling = Request::ClearExplicit)
    {
        setInclude({}, explicitHandling);
    }

    [[nodiscard]] Input input() const { return mInput; }
    bool setInput(const Input& input,
                  Request::ExplicitHandling explicitHandling = Request::SetExplicit)
    {
        updateExplicit(Request::ConversationAttribute, explicitHandling);
        if (mInput == input)
            return false;
        mInput = input;
        return true;
    }
    void resetInput(Request::ExplicitHandling explicitHandling = Request::ClearExplicit)
    {
        setInput({}, explicitHandling);
    }

    [[nodiscard]] QString instructions() const { return mInstructions; }
    bool setInstructions(const QString& instructions,
                         Request::ExplicitHandling explicitHandling = Request::SetExplicit)
    {
        updateExplicit(Request::ConversationAttribute, explicitHandling);
        if (mInstructions == instructions)
            return false;
        mInstructions = instructions;
        return true;
    }
    void resetInstructions(Request::ExplicitHandling explicitHandling = Request::ClearExplicit)
    {
        setInstructions({}, explicitHandling);
    }

    [[nodiscard]] int maxOutputTokens() const { return mMaxOutputTokens; }
    bool setMaxOutputTokens(int maxOutputTokens,
                            Request::ExplicitHandling explicitHandling = Request::SetExplicit)
    {
        updateExplicit(Request::ConversationAttribute, explicitHandling);
        if (mMaxOutputTokens == maxOutputTokens)
            return false;
        mMaxOutputTokens = maxOutputTokens;
        return true;
    }
    void resetMaxOutputTokens(Request::ExplicitHandling explicitHandling = Request::ClearExplicit)
    {
        setMaxOutputTokens(0, explicitHandling);
    }

    [[nodiscard]] int maxToolCalls() const { return mMaxToolCalls; }
    bool setMaxToolCalls(int maxToolCalls,
                         Request::ExplicitHandling explicitHandling = Request::SetExplicit)
    {
        updateExplicit(Request::ConversationAttribute, explicitHandling);
        if (mMaxToolCalls == maxToolCalls)
            return false;
        mMaxToolCalls = maxToolCalls;
        return true;
    }
    void resetMaxToolCalls(Request::ExplicitHandling explicitHandling = Request::ClearExplicit)
    {
        setMaxToolCalls(0, explicitHandling);
    }

    [[nodiscard]] bool parallelToolCalls() const { return mParallelToolCalls; }
    bool setParallelToolCalls(bool parallelToolCalls,
                              Request::ExplicitHandling explicitHandling = Request::SetExplicit)
    {
        updateExplicit(Request::ConversationAttribute, explicitHandling);
        if (mParallelToolCalls == parallelToolCalls)
            return false;
        mParallelToolCalls = parallelToolCalls;
        return true;
    }
    void resetParallelToolCalls(Request::ExplicitHandling explicitHandling = Request::ClearExplicit)
    {
        setParallelToolCalls(true, explicitHandling);
    }

    [[nodiscard]] QString previousResponseId() const { return mPreviousResponseId; }
    bool setPreviousResponseId(const QString& previousResponseId,
                               Request::ExplicitHandling explicitHandling = Request::SetExplicit)
    {
        updateExplicit(Request::ConversationAttribute, explicitHandling);
        if (mPreviousResponseId == previousResponseId)
            return false;
        mPreviousResponseId = previousResponseId;
        return true;
    }
    void resetPreviousResponseId(Request::ExplicitHandling explicitHandling = Request::ClearExplicit)
    {
        setPreviousResponseId({}, explicitHandling);
    }

    // [[nodiscard]] AiPrompt prompt() const;
    // bool setPrompt(const AiPrompt& prompt,
    // Request::ExplicitHandling explicitHandling = Request::SetExplicit);
    // void resetPrompt(Request::ExplicitHandling explicitHandling = Request::ClearExplicit) { setPrompt({}); }

    /** prompt_cache_key
        string
        Optional
        Used by OpenAI to cache responses for similar requests to optimize your cache hit rates. Replaces the user field. Learn more.
    */
    [[nodiscard]] QString promptCacheKey() const { return mPromptCacheKey; }
    bool setPromptCacheKey(const QString& promptCacheKey,
                           Request::ExplicitHandling explicitHandling = Request::SetExplicit)
    {
        updateExplicit(Request::ConversationAttribute, explicitHandling);
        if (mPromptCacheKey == promptCacheKey)
            return false;
        mPromptCacheKey = promptCacheKey;
        return true;
    }
    void resetPromptCacheKey(Request::ExplicitHandling explicitHandling = Request::ClearExplicit)
    {
        setPromptCacheKey({}, explicitHandling);
    }

    /** reasoning
        object
        Optional
        gpt-5 and o-series models only
        Configuration options for reasoning models.
    */
    [[nodiscard]] Reasoning reasoning() const { return mReasoning; }
    bool setReasoning(const Reasoning& reasoning,
                      Request::ExplicitHandling explicitHandling = Request::SetExplicit)
    {
        updateExplicit(Request::ConversationAttribute, explicitHandling);
        if (mReasoning == reasoning)
            return false;
        mReasoning = reasoning;
        return true;
    }
    void resetReasoning(Request::ExplicitHandling explicitHandling = Request::ClearExplicit)
    {
        setReasoning({}, explicitHandling);
    }

    /** safety_identifier
        string
        Optional
        A stable identifier used to help detect users of your application that may be violating OpenAI's usage policies. The IDs should be a string that uniquely identifies each user. We recommend hashing their username or email address, in order to avoid sending us any identifying information. Learn more.
    */
    [[nodiscard]] QString safetyIdetifier() const;
    bool setSafetyIdetifier(const QString& safetyIdetifier,
                            Request::ExplicitHandling explicitHandling = Request::SetExplicit);
    void resetSafetyIdetifier(Request::ExplicitHandling explicitHandling = Request::ClearExplicit)
    {
        setSafetyIdetifier({}, explicitHandling);
    }

    /** service_tier
        string
        Optional
        Defaults to auto
        Specifies the processing type used for serving the request.
            If set to 'auto', then the request will be processed with the service tier configured in the Project settings. Unless otherwise configured, the Project will use 'default'.
            If set to 'default', then the request will be processed with the standard pricing and performance for the selected model.
            If set to 'flex' or 'priority', then the request will be processed with the corresponding service tier.
            When not set, the default behavior is 'auto'.
        When the service_tier parameter is set, the response body will include the service_tier value based on the processing mode actually used to serve the request. This response value may be different from the value set in the parameter.
    */
    [[nodiscard]] QString serviceTier() const;
    bool setServiceTier(const QString& serviceTier,
                        Request::ExplicitHandling explicitHandling = Request::SetExplicit);
    void resetServiceTier(Request::ExplicitHandling explicitHandling = Request::ClearExplicit)
    {
        setServiceTier(QStringLiteral("auto"), explicitHandling);
    }

    /** isStored
        boolean
        Optional
        Defaults to true
        Whether to isStored the generated model response for later retrieval via API.
    */
    [[nodiscard]] bool isStored() const { return mStored; }
    bool setStored(bool store, Request::ExplicitHandling explicitHandling = Request::SetExplicit)
    {
        updateExplicit(Request::ConversationAttribute, explicitHandling);
        if (mStored == store)
            return false;
        mStored = store;
        return true;
    }
    void resetStored(Request::ExplicitHandling explicitHandling = Request::ClearExplicit)
    {
        setStored(true, explicitHandling);
    }

    [[nodiscard]] double temperature() const { return mTemperature; }
    bool setTemperature(double temperature,
                        Request::ExplicitHandling explicitHandling = Request::SetExplicit)
    {
        updateExplicit(Request::ConversationAttribute, explicitHandling);
        if (mTemperature == temperature)
            return false;
        mTemperature = temperature;
        return true;
    }
    void resetTemperature(Request::ExplicitHandling explicitHandling = Request::ClearExplicit)
    {
        setTemperature(1.0, explicitHandling);
    }

    // [[nodiscard]] AiText text() const;
    // bool setText(const AiText& text,
    // Request::ExplicitHandling explicitHandling = Request::SetExplicit);
    // void resetText(Request::ExplicitHandling explicitHandling = Request::ClearExplicit) { setText({}); }

    // [[nodiscard]] AiToolChoice toolChoice() const;
    // bool setToolChoice(const AiToolChoice& toolChoice,
    // Request::ExplicitHandling explicitHandling = Request::SetExplicit);
    // void resetToolChoice(Request::ExplicitHandling explicitHandling = Request::ClearExplicit) { setToolChoice({}); }

    // [[nodiscard]] AiTools tools() const;
    // bool setTools(const AiTools& tools,
    // Request::ExplicitHandling explicitHandling = Request::SetExplicit);
    // void resetTools(Request::ExplicitHandling explicitHandling = Request::ClearExplicit) { setTools({}); }

    [[nodiscard]] int topLogprobs() const;
    bool setTopLogprobs(int topLogprobs,
                        Request::ExplicitHandling explicitHandling = Request::SetExplicit);
    void resetTopLogprobs(Request::ExplicitHandling explicitHandling = Request::ClearExplicit)
    {
        setTopLogprobs(0, explicitHandling);
    }

    [[nodiscard]] double topP() const;
    bool setTopP(double topP, Request::ExplicitHandling explicitHandling = Request::SetExplicit);
    void resetTopP(Request::ExplicitHandling explicitHandling = Request::ClearExplicit)
    {
        setTopP(1.0, explicitHandling);
    }

    [[nodiscard]] Truncation truncation() const;
    bool setTruncation(Truncation truncation,
                       Request::ExplicitHandling explicitHandling = Request::SetExplicit);
    bool setTruncation(const QString& truncation,
                       Request::ExplicitHandling explicitHandling = Request::SetExplicit);
    void resetTruncation(Request::ExplicitHandling explicitHandling = Request::ClearExplicit)
    {
        setTruncation(Truncation::TruncationDisabled, explicitHandling);
    }

    bool readJson(const QJsonObject& json, QStringList* errors = nullptr) override;
    bool writeJson(QJsonObject& json, bool full = false) const override;
};

} // namespace ai::responses

#endif // AI_RESPONSES_REQUEST_H
