#include "request.h"
#include "client.h"

namespace ai::responses {

bool RequestData::readJson(const QJsonObject &json, QStringList *errors)
{
    bool ok = ai::RequestData::readJson(json);

    if (json.contains(QStringLiteral("background"))) {
        if (const auto v = json.value(QStringLiteral("background")); v.isBool()) {
            setBackground(v.toBool());
            extra().remove(QStringLiteral("background"));
        } else {
            if (errors)
                errors->append("background is not a boolean");
            ok = false;
        }
    }

    if (json.contains(QStringLiteral("conversation"))) {
        if (const auto v = json.value(QStringLiteral("conversation")); v.isString()) {
            setConversation(v.toString());
            extra().remove(QStringLiteral("conversation"));
        } else if (v.isObject()) {
            setConversation(Conversation::fromJson(v.toObject()));
            extra().remove(QStringLiteral("conversation"));
        } else {
            if (errors)
                errors->append("conversation is not a string or object");
            ok = false;
        }
    }

    if (json.contains(QStringLiteral("input"))) {
        if (const auto v = json.value(QStringLiteral("input")); v.isString()) {
            setInput({v.toString()});
            extra().remove(QStringLiteral("input"));
        } else if (v.isArray()) {
            setInput(Input::fromJson(v.toArray()));
            extra().remove(QStringLiteral("input"));
        } else {
            if (errors)
                errors->append("input is not a string or array");
            ok = false;
        }
    }

    return ok;
}

bool RequestData::writeJson(QJsonObject &json, bool full) const
{
    if (!ai::RequestData::writeJson(json, full))
        return false;

    if (const auto v = background(); full || v)
        json[QStringLiteral("background")] = v;

    if (const auto v = conversation(); full || !v.isEmpty())
        json[QStringLiteral("conversation")] = v.toJson();

    if (const auto v = input(); full || !v.isEmpty())
        json[QStringLiteral("input")] = v.toJson();

    if (const auto v = instructions(); full || !v.isEmpty())
        json[QStringLiteral("instructions")] = v;

    if (full || !isStored())
        json[QStringLiteral("store")] = isStored();

    if (const auto v = temperature(); full || v != 1.0)
        json[QStringLiteral("temperature")] = v;

    return true;
}

RequestData *Request::d()
{
    return static_cast<RequestData *>(ai::Request::d.data());
}

const RequestData *Request::d() const
{
    return static_cast<const RequestData *>(ai::Request::d.data());
}

Request::Request()
    : Request(new RequestData)
{}

// Request &Request::operator=(const Request &rhs)
// {
//     ai::Request::operator=(rhs);
//     return *this;
// }

bool Request::background() const
{
    return d()->background();
}

Request &Request::setBackground(bool background)
{
    d()->setBackground(background);
    return *this;
}

Request &Request::resetBackground()
{
    d()->resetBackground();
    return *this;
}

Conversation Request::conversation() const
{
    return d()->conversation();
}

Request &Request::setConversation(const Conversation &conversation)
{
    d()->setConversation(conversation);
    return *this;
}

Request &Request::resetConversation()
{
    d()->resetConversation();
    return *this;
}

IncludeList Request::include() const
{
    return d()->include();
}

Request &Request::setInclude(const IncludeList &include)
{
    d()->setInclude(include);
    return *this;
}

Request &Request::resetInclude()
{
    d()->resetInclude();
    return *this;
}

Input Request::input() const
{
    return d()->input();
}

Request &Request::setInput(const Input &input)
{
    d()->setInput(input);
    return *this;
}

Request &Request::resetInput()
{
    d()->resetInput();
    return *this;
}

QString Request::instructions() const
{
    return d()->instructions();
}

Request &Request::setInstructions(const QString &instructions)
{
    d()->setInstructions(instructions);
    return *this;
}

Request &Request::resetInstructions()
{
    d()->resetInstructions();
    return *this;
}

Request &Request::resetMaxOutputTokens()
{
    d()->resetMaxOutputTokens();
    return *this;
}

Request &Request::resetMaxToolCalls()
{
    d()->resetMaxToolCalls();
    return *this;
}

QString Request::previousResponseId() const
{
    return d()->previousResponseId();
}

Request &Request::setPreviousResponseId(const QString &previousResponseId)
{
    d()->setPreviousResponseId(previousResponseId);
    return *this;
}

Request &Request::resetPreviousResponseId()
{
    d()->resetPreviousResponseId();
    return *this;
}

Request &Request::resetPromptCacheKey()
{
    d()->resetPromptCacheKey();
    return *this;
}

Reasoning Request::reasoning() const
{
    return d()->reasoning();
}

Request &Request::setReasoning(const Reasoning &reasoning)
{
    d()->setReasoning(reasoning);
    return *this;
}

Request &Request::resetReasoning()
{
    d()->resetReasoning();
    return *this;
}

Request &Request::resetSafetyIdetifier()
{
    d()->resetSafetyIdetifier();
    return *this;
}

Request &Request::resetServiceTier()
{
    d()->resetServiceTier();
    return *this;
}

bool Request::isStored() const
{
    return d()->isStored();
}

Request &Request::setStored(bool store)
{
    d()->setStored(store);
    return *this;
}

double Request::temperature() const
{
    return d()->temperature();
}

Request &Request::setTemperature(double temperature)
{
    d()->setTemperature(temperature);
    return *this;
}

Request &Request::resetTemperature()
{
    d()->resetTemperature();
    return *this;
}

Request &Request::resetTopLogprobs()
{
    d()->resetTopLogprobs();
    return *this;
}

Request &Request::resetTopP()
{
    d()->resetTopP();
    return *this;
}

Request &Request::resetTruncation()
{
    d()->resetTruncation();
    return *this;
}

Request::Request(RequestData* data)
    : ai::Request{data ? data : new RequestData}
{}

} // namespace ai::responses
