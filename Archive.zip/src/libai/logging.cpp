#include "logging.h"

Q_LOGGING_CATEGORY(LOGAI, "ai")
